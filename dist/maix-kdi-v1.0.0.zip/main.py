"""
MaixCAM: detect orange dashed lane line, fit a straight line through it, and
transmit the result to the MCU (Yolo Uno / ESP32-S3) over UART0.

Assumes MaixPy for MaixCAM (CPython, `maix` module). Tested API surface:
camera.Camera, display.Display, image.Image.find_blobs/binary/draw_*, app.need_exit,
uart.UART (UART0 = A16 TX / A17 RX on the pin header, no pinmap needed).

Set DEBUG_MASK = True first to tune ORANGE_THRESHOLD (see notes at bottom).

Wire protocol (one JSON line per frame, matches the MaixCAM<->YoloUno bounding-box
schema from https://github.com/rnd-kdi/kdi-maixcam-yolouno-extension so the MCU side
can read it with a small reader class, no separate camera_riscv.py file needed):
    line found : {"c": 1, "o": [{"l": "line", "x": <int px>, "y": <int REF_ROW>, "w": 0, "h": 0}]}
    line lost  : {"c": 0, "o": []}
`x` is an ABSOLUTE pixel coordinate (0..IMG_W-1), not a centered offset -- the MCU
side's track_x/target_x work in raw pixel space (see main.py's TARGET_X=160).
`y` is always the fixed REF_ROW: there's no meaningful "distance" for an infinite
line the way there is for a tracked object, so it's a constant, not a measurement.
"""

from maix import camera, display, image, app, uart

try:
    import ujson as json
except ImportError:
    import json

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
IMG_W, IMG_H = 320, 240

# LAB threshold for orange tape/paint: [L min, L max, A min, A max, B min, B max]
# Starting guess -- almost certainly needs tuning to your lighting, see notes below.
ORANGE_THRESHOLD = [[35, 100, 10, 75, 25, 90]]

MIN_PIXELS = 15                                   # drop specks smaller than this
ROI = (0, IMG_H // 3, IMG_W, IMG_H - IMG_H // 3)   # only search lower 2/3 of frame
REF_ROW = IMG_H - 10                               # row used to measure lane position (near the car)

DEBUG_MASK = False   # True: show the raw color mask instead of the annotated frame

cam = camera.Camera(IMG_W, IMG_H)
disp = display.Display()

# UART0 (A16=TX / A17=RX on the header) -- default pins, no pinmap.set_pin_function() needed.
serial_dev = uart.UART("/dev/ttyS0", 115200)


def fit_line_xy(points):
    """Weighted least-squares fit of x = m*y + b over (x, y, weight) points.

    Fitting x as a function of y keeps the solution well-behaved when the
    lane is close to vertical in the image, which is the normal case for a
    forward-facing camera (a plain y = m*x + b fit blows up there).
    """
    sw = sy = sx = syy = sxy = 0.0
    for x, y, w in points:
        sw += w
        sy += w * y
        sx += w * x
        syy += w * y * y
        sxy += w * x * y
    denom = sw * syy - sy * sy
    if sw == 0 or abs(denom) < 1e-6:
        return None
    m = (sw * sxy - sx * sy) / denom
    b = (sx - m * sy) / sw
    return m, b


def send_line(x_abs):
    # x_abs=None -> line not found this frame ("c":0). Otherwise absolute pixel x.
    if x_abs is None:
        msg = {"c": 0, "o": []}
    else:
        msg = {"c": 1, "o": [{"l": "line", "x": int(x_abs), "y": REF_ROW, "w": 0, "h": 0}]}
    serial_dev.write_str(json.dumps(msg) + "\n")


while not app.need_exit():
    img = cam.read()

    if DEBUG_MASK:
        mask = img.copy()
        mask.binary(ORANGE_THRESHOLD)
        disp.show(mask)
        continue

    blobs = img.find_blobs(
        ORANGE_THRESHOLD,
        roi=ROI,
        pixels_threshold=MIN_PIXELS,
        area_threshold=MIN_PIXELS,
        merge=True,
        margin=10,
    )

    points = []
    for b in blobs:
        img.draw_rect(b.x(), b.y(), b.w(), b.h(), color=image.Color.from_rgb(0, 255, 0))
        img.draw_cross(b.cx(), b.cy(), color=image.Color.from_rgb(0, 255, 0))
        points.append((b.cx(), b.cy(), b.pixels()))

    # Need >=2 dashes to fit a slope -- a lone dash has no slope information,
    # so we don't try to extrapolate from it (the MCU-side miss-threshold hold
    # bridges single/zero-blob gaps instead, see main_lane.py).
    offset = None
    x_abs = None
    if len(points) >= 2:
        fit = fit_line_xy(points)
        if fit is not None:
            m, c = fit
            y0, y1 = ROI[1], IMG_H - 1
            x0, x1 = int(m * y0 + c), int(m * y1 + c)
            img.draw_line(x0, y0, x1, y1, color=image.Color.from_rgb(255, 0, 0), thickness=2)
            x_abs = m * REF_ROW + c
            if x_abs < 0:
                x_abs = 0
            elif x_abs > IMG_W - 1:
                x_abs = IMG_W - 1
            offset = x_abs - IMG_W / 2   # negative = lane is left of center (debug display only)

    send_line(x_abs)

    img.draw_line(IMG_W // 2, 0, IMG_W // 2, IMG_H - 1, color=image.Color.from_rgb(255, 255, 0), thickness=1)
    img.draw_string(
        4, 4,
        "offset: {:.1f}px".format(offset) if offset is not None else "lane not found",
        color=image.Color.from_rgb(255, 255, 0) if offset is not None else image.Color.from_rgb(255, 0, 0),
    )

    disp.show(img)

# ---------------------------------------------------------------------------
# Tuning ORANGE_THRESHOLD
# ---------------------------------------------------------------------------
# 1. Set DEBUG_MASK = True and run. You'll see a binary (black/white) view:
#    white = pixels currently matching the threshold.
# 2. Point the camera at the lane so both orange dashes and background are
#    visible. Adjust the 6 numbers:
#      - L (lightness) range: widen if dashes look dim/dark and aren't white
#        in the mask, narrow if background is falsely white.
#      - A range (green<->red): orange sits mid-to-high positive A. Raise the
#        floor if red/skin-tone background bleeds into the mask.
#      - B range (blue<->yellow): orange sits high positive B. This is
#        usually the most selective channel for orange vs. red/pink.
# 3. Iterate until only the dashes are white, then set DEBUG_MASK = False.
#
# ---------------------------------------------------------------------------
# MCU side
# ---------------------------------------------------------------------------
# See main_lane.py: reads the JSON lines above via UART(1) on D3/D4, holds the
# last known x for a few missed frames (dash gaps), and feeds x into
# visionbot.track_x(x, target_x) with an off-center target_x to bias the robot
# to one side of the line ("outer"/"inner" lane).
